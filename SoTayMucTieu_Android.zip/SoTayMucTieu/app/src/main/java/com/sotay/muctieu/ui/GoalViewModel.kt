package com.sotay.muctieu.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.sotay.muctieu.alarm.AlarmScheduler
import com.sotay.muctieu.data.GoalDatabase
import com.sotay.muctieu.data.GoalEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class GoalViewModel(application: Application) : AndroidViewModel(application) {
    private val db = GoalDatabase.getDatabase(application)
    private val dao = db.goalDao()
    private val alarmScheduler = AlarmScheduler(application)

    val goalsFlow = dao.getAllGoalsFlow()

    private val _wallpaperUri = MutableStateFlow<String?>(null)
    val wallpaperUri: StateFlow<String?> = _wallpaperUri.asStateFlow()

    private val _soundEnabled = MutableStateFlow(true)
    val soundEnabled: StateFlow<Boolean> = _soundEnabled.asStateFlow()

    private val _isNotificationGranted = MutableStateFlow(true)
    val isNotificationGranted: StateFlow<Boolean> = _isNotificationGranted.asStateFlow()

    fun updateNotificationPermission(granted: Boolean) {
        _isNotificationGranted.value = granted
    }

    fun setBackgroundWallpaperUri(uri: String?) {
        _wallpaperUri.value = uri
    }

    fun toggleSound(enabled: Boolean) {
        _soundEnabled.value = enabled
    }

    fun addGoal(title: String, content: String, reminderTimestamp: Long, onResult: (Boolean, String?) -> Unit) {
        if (reminderTimestamp <= System.currentTimeMillis()) {
            onResult(false, "Thời gian nhắc nhở phải ở tương lai, không thể chọn thời gian trong quá khứ.")
            return
        }
        if (title.isBlank()) {
            onResult(false, "Vui lòng nhập tiêu đề cho mục tiêu.")
            return
        }
        viewModelScope.launch {
            val entity = GoalEntity(
                title = title.trim(),
                content = content.trim(),
                reminderTimestamp = reminderTimestamp,
                isCompleted = false
            )
            val newId = dao.insertGoal(entity)
            alarmScheduler.schedule(entity.copy(id = newId))
            onResult(true, null)
        }
    }

    fun updateGoal(goal: GoalEntity, onResult: (Boolean, String?) -> Unit) {
        if (goal.reminderTimestamp <= System.currentTimeMillis() && !goal.isCompleted) {
            onResult(false, "Thời gian nhắc nhở phải ở tương lai.")
            return
        }
        viewModelScope.launch {
            dao.updateGoal(goal)
            if (goal.isCompleted) {
                alarmScheduler.cancel(goal.id)
            } else {
                alarmScheduler.schedule(goal)
            }
            onResult(true, null)
        }
    }

    fun toggleComplete(goal: GoalEntity) {
        viewModelScope.launch {
            val updated = goal.copy(isCompleted = !goal.isCompleted)
            dao.updateGoal(updated)
            if (updated.isCompleted) {
                alarmScheduler.cancel(goal.id)
            } else if (updated.reminderTimestamp > System.currentTimeMillis()) {
                alarmScheduler.schedule(updated)
            }
        }
    }

    fun deleteGoal(goal: GoalEntity) {
        viewModelScope.launch {
            dao.deleteGoal(goal)
            alarmScheduler.cancel(goal.id)
        }
    }
}
