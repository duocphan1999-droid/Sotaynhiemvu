package com.sotay.muctieu.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/**
 * Giao diện DAO xử lý các thao tác truy vấn dữ liệu Room Database.
 * Dùng Kotlin Flow để tự động phát tín hiệu cập nhật khi dữ liệu thay đổi.
 */
@Dao
interface GoalDao {
    @Query("SELECT * FROM goals ORDER BY isCompleted ASC, reminderTimestamp ASC")
    fun getAllGoalsFlow(): Flow<List<GoalEntity>>

    @Query("SELECT * FROM goals WHERE isCompleted = 0 AND reminderTimestamp > :currentTime")
    suspend fun getUpcomingGoals(currentTime: Long): List<GoalEntity>

    @Query("SELECT * FROM goals WHERE id = :id LIMIT 1")
    suspend fun getGoalById(id: Long): GoalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertGoal(goal: GoalEntity): Long

    @Update
    suspend fun updateGoal(goal: GoalEntity)

    @Delete
    suspend fun deleteGoal(goal: GoalEntity)
}
