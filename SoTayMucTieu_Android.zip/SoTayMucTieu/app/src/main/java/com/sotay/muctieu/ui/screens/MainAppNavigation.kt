package com.sotay.muctieu.ui.screens

import androidx.compose.runtime.*
import com.sotay.muctieu.data.GoalEntity
import com.sotay.muctieu.ui.GoalViewModel

@Composable
fun MainAppNavigation(
    viewModel: GoalViewModel,
    onPickWallpaper: () -> Unit,
    onOpenExactAlarmSettings: () -> Unit
) {
    var isSettingsOpen by remember { mutableStateOf(false) }
    var isDialogOpen by remember { mutableStateOf(false) }
    var editingGoal by remember { mutableStateOf<GoalEntity?>(null) }

    val goals by viewModel.goalsFlow.collectAsState(initial = emptyList())

    if (isSettingsOpen) {
        SettingsScreen(
            viewModel = viewModel,
            onBack = { isSettingsOpen = false },
            onPickWallpaper = onPickWallpaper,
            onOpenExactAlarmSettings = onOpenExactAlarmSettings
        )
    } else {
        HomeScreen(
            goals = goals,
            onAddGoalClick = {
                editingGoal = null
                isDialogOpen = true
            },
            onEditGoalClick = {
                editingGoal = it
                isDialogOpen = true
            },
            onDeleteGoalClick = { viewModel.deleteGoal(it) },
            onToggleComplete = { viewModel.toggleComplete(it) },
            onOpenSettings = { isSettingsOpen = true }
        )
    }

    if (isDialogOpen) {
        GoalDialog(
            initialGoal = editingGoal,
            onDismiss = { isDialogOpen = false },
            onSave = { title, content, timestamp ->
                if (editingGoal != null) {
                    viewModel.updateGoal(
                        editingGoal!!.copy(
                            title = title,
                            content = content,
                            reminderTimestamp = timestamp
                        )
                    ) { _, _ -> }
                } else {
                    viewModel.addGoal(title, content, timestamp) { _, _ -> }
                }
            }
        )
    }
}
