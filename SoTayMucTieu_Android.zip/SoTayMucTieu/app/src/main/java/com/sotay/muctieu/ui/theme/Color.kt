package com.sotay.muctieu.ui.theme

import androidx.compose.ui.graphics.Color

val CreamPaperBackground = Color(0xFFF6F0E4)
val CreamPaperCard = Color(0xFFFCF9F2)
val CreamPaperElevated = Color(0xFFEFE8DA)
val DarkBrownInk = Color(0xFF3A2E2B)
val MediumBrownInk = Color(0xFF6E5D53)
val SubtleBrownBorder = Color(0xFFD6C8B4)
val TerracottaAccent = Color(0xFFC8644A)
val OliveGreenAccent = Color(0xFF4F7A59)
val AmberWarmAccent = Color(0xFFD98A3C)
