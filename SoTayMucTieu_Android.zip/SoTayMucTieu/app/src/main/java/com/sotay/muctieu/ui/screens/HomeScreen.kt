package com.sotay.muctieu.ui.screens

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Circle
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sotay.muctieu.data.GoalEntity
import com.sotay.muctieu.ui.theme.*
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(
    goals: List<GoalEntity>,
    onAddGoalClick: () -> Unit,
    onEditGoalClick: (GoalEntity) -> Unit,
    onDeleteGoalClick: (GoalEntity) -> Unit,
    onToggleComplete: (GoalEntity) -> Unit,
    onOpenSettings: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Sổ Tay Mục Tiêu",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = DarkBrownInk
                            )
                        )
                        Text(
                            text = "${goals.count { it.isCompleted }}/${goals.size} mục tiêu hoàn thành",
                            style = MaterialTheme.typography.bodySmall.copy(color = MediumBrownInk)
                        )
                    }
                },
                actions = {
                    IconButton(onClick = onOpenSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Cài đặt", tint = DarkBrownInk)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = CreamPaperBackground
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(
                onClick = onAddGoalClick,
                containerColor = TerracottaAccent,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = "Thêm mục tiêu")
            }
        },
        containerColor = CreamPaperBackground
    ) { padding ->
        if (goals.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = "Chưa có mục tiêu nào trong sổ tay.\nHãy bấm dấu + để viết mục tiêu mới!",
                    color = MediumBrownInk,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(goals, key = { it.id }) { goal ->
                    GoalCardItem(
                        goal = goal,
                        onEdit = { onEditGoalClick(goal) },
                        onDelete = { onDeleteGoalClick(goal) },
                        onToggle = { onToggleComplete(goal) }
                    )
                }
            }
        }
    }
}

@Composable
fun GoalCardItem(
    goal: GoalEntity,
    onEdit: () -> Unit,
    onDelete: () -> Unit,
    onToggle: () -> Unit
) {
    val cardBackground by animateColorAsState(
        targetValue = if (goal.isCompleted) CreamPaperElevated else CreamPaperCard,
        label = "cardBg"
    )

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .border(1.dp, SubtleBrownBorder, RoundedCornerShape(14.dp))
            .clickable { onEdit() },
        colors = CardDefaults.cardColors(containerColor = cardBackground),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                    IconButton(onClick = onToggle) {
                        if (goal.isCompleted) {
                            Icon(Icons.Filled.CheckCircle, "Hoàn thành", tint = OliveGreenAccent)
                        } else {
                            Icon(Icons.Outlined.Circle, "Chưa xong", tint = MediumBrownInk)
                        }
                    }
                    Text(
                        text = goal.title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = FontWeight.SemiBold,
                            color = if (goal.isCompleted) MediumBrownInk else DarkBrownInk,
                            textDecoration = if (goal.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                        )
                    )
                }

                Row {
                    IconButton(onClick = onEdit) {
                        Icon(Icons.Filled.Edit, "Chỉnh sửa", tint = MediumBrownInk)
                    }
                    IconButton(onClick = onDelete) {
                        Icon(Icons.Filled.Delete, "Xóa", tint = TerracottaAccent)
                    }
                }
            }

            if (goal.content.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = goal.content,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = MediumBrownInk,
                        lineHeight = 20.sp
                    ),
                    modifier = Modifier.padding(start = 48.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))
            val dateFormat = SimpleDateFormat("HH:mm - 'Ngày' dd/MM/yyyy", Locale.getDefault())
            val timeText = dateFormat.format(Date(goal.reminderTimestamp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(start = 48.dp)
            ) {
                Icon(
                    Icons.Outlined.Schedule,
                    contentDescription = "Hẹn giờ",
                    tint = if (goal.reminderTimestamp < System.currentTimeMillis() && !goal.isCompleted) TerracottaAccent else MediumBrownInk,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "Nhắc nhở: $timeText",
                    style = MaterialTheme.typography.bodySmall.copy(
                        color = if (goal.reminderTimestamp < System.currentTimeMillis() && !goal.isCompleted) TerracottaAccent else MediumBrownInk
                    )
                )
            }
        }
    }
}
