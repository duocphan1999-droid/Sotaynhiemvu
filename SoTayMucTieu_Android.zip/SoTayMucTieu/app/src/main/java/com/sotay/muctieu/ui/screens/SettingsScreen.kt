package com.sotay.muctieu.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sotay.muctieu.ui.GoalViewModel
import com.sotay.muctieu.ui.theme.CreamPaperBackground
import com.sotay.muctieu.ui.theme.DarkBrownInk
import com.sotay.muctieu.ui.theme.TerracottaAccent

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: GoalViewModel,
    onBack: () -> Unit,
    onPickWallpaper: () -> Unit,
    onOpenExactAlarmSettings: () -> Unit
) {
    val soundEnabled by viewModel.soundEnabled.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Cài Đặt Sổ Tay", color = DarkBrownInk) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Quay lại", tint = DarkBrownInk)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = CreamPaperBackground)
            )
        },
        containerColor = CreamPaperBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Card(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Âm thanh nhắc nhở", style = MaterialTheme.typography.titleMedium, color = DarkBrownInk)
                        Text("Phát chuông khi đến hạn mục tiêu", style = MaterialTheme.typography.bodySmall)
                    }
                    Switch(
                        checked = soundEnabled,
                        onCheckedChange = { viewModel.toggleSound(it) }
                    )
                }
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Hình nền tùy biến", style = MaterialTheme.typography.titleMedium, color = DarkBrownInk)
                    Text("Chọn ảnh từ thư viện máy (Photo Picker) làm hình nền sổ tay.", style = MaterialTheme.typography.bodySmall)
                    Button(
                        onClick = onPickWallpaper,
                        colors = ButtonDefaults.buttonColors(containerColor = TerracottaAccent)
                    ) {
                        Text("Chọn ảnh từ thư viện")
                    }
                }
            }

            Card(
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tối ưu hóa trên vivo T1x", style = MaterialTheme.typography.titleMedium, color = DarkBrownInk)
                    Text("Trên Funtouch OS, hãy chọn 'Cho phép hoạt động nền cao' trong mục Cài đặt Pin để chuông báo thức đổ đúng giờ.", style = MaterialTheme.typography.bodySmall)
                    OutlinedButton(onClick = onOpenExactAlarmSettings) {
                        Text("Mở cài đặt báo thức chính xác")
                    }
                }
            }
        }
    }
}
