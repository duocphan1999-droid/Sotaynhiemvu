package com.sotay.muctieu.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.sotay.muctieu.data.GoalDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootAndConfigReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED,
            Intent.ACTION_TIME_CHANGED,
            Intent.ACTION_TIMEZONE_CHANGED,
            Intent.ACTION_MY_PACKAGE_REPLACED -> {
                CoroutineScope(Dispatchers.IO).launch {
                    val db = GoalDatabase.getDatabase(context)
                    val scheduler = AlarmScheduler(context)
                    val now = System.currentTimeMillis()
                    val upcomingGoals = db.goalDao().getUpcomingGoals(now)
                    for (goal in upcomingGoals) {
                        scheduler.schedule(goal)
                    }
                }
            }
        }
    }
}
