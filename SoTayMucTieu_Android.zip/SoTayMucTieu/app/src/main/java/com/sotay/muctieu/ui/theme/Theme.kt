package com.sotay.muctieu.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

private val LightColorScheme = lightColorScheme(
    primary = TerracottaAccent,
    onPrimary = CreamPaperCard,
    secondary = OliveGreenAccent,
    onSecondary = CreamPaperCard,
    background = CreamPaperBackground,
    onBackground = DarkBrownInk,
    surface = CreamPaperCard,
    onSurface = DarkBrownInk,
    surfaceVariant = CreamPaperElevated,
    outline = SubtleBrownBorder
)

@Composable
fun SoTayMucTieuTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LightColorScheme,
        typography = Typography,
        content = content
    )
}
