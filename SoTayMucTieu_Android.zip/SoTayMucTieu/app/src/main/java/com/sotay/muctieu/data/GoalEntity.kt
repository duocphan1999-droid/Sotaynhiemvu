package com.sotay.muctieu.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Bảng dữ liệu "goals" trong Room Database.
 * Lưu trữ tiêu đề, nội dung, thời gian hẹn giờ và trạng thái hoàn thành.
 */
@Entity(tableName = "goals")
data class GoalEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val title: String,
    val content: String,
    val reminderTimestamp: Long, // Thời gian nhắc tính bằng mili-giây (epoch time)
    val isCompleted: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
