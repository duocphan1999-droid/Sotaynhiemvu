package com.sotay.muctieu.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.sotay.muctieu.data.GoalEntity
import com.sotay.muctieu.ui.theme.DarkBrownInk
import com.sotay.muctieu.ui.theme.TerracottaAccent
import java.util.Calendar

@Composable
fun GoalDialog(
    initialGoal: GoalEntity? = null,
    onDismiss: () -> Unit,
    onSave: (title: String, content: String, reminderTimestamp: Long) -> Unit
) {
    var title by remember { mutableStateOf(initialGoal?.title ?: "") }
    var content by remember { mutableStateOf(initialGoal?.content ?: "") }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    // Hẹn giờ mặc định: 2 giờ sau
    val calendar = remember {
        Calendar.getInstance().apply {
            if (initialGoal != null) {
                timeInMillis = initialGoal.reminderTimestamp
            } else {
                add(Calendar.HOUR_OF_DAY, 2)
            }
        }
    }
    var reminderTime by remember { mutableLongStateOf(calendar.timeInMillis) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialGoal != null) "Sửa Mục Tiêu" else "Thêm Mục Tiêu Mới",
                color = DarkBrownInk
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                if (errorMsg != null) {
                    Text(text = errorMsg!!, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it; errorMsg = null },
                    label = { Text("Tiêu đề mục tiêu") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = content,
                    onValueChange = { content = it },
                    label = { Text("Chi tiết kế hoạch") },
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = "Thời gian nhắc nhở sẽ được đặt sau 2 giờ hoặc tùy chỉnh theo ngày giờ.",
                    style = MaterialTheme.typography.bodySmall,
                    color = DarkBrownInk
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isBlank()) {
                        errorMsg = "Vui lòng nhập tiêu đề"
                    } else if (reminderTime <= System.currentTimeMillis()) {
                        errorMsg = "Không thể đặt thời gian ở quá khứ"
                    } else {
                        onSave(title, content, reminderTime)
                        onDismiss()
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = TerracottaAccent)
            ) {
                Text("Lưu mục tiêu")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Hủy", color = DarkBrownInk)
            }
        },
        shape = RoundedCornerShape(16.dp)
    )
}
