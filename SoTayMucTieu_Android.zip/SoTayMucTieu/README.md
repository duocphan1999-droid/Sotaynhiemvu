# SỔ TAY MỤC TIÊU (Android Native - Kotlin & Jetpack Compose)
Package: `com.sotay.muctieu`
Dành riêng cho: Người mới bắt đầu học lập trình Android & tối ưu giao diện trên vivo T1x.

---

## 1. Giới thiệu dự án
Ứng dụng **Sổ Tay Mục Tiêu** là ứng dụng Android Native hoàn chỉnh, sử dụng:
- **Ngôn ngữ**: Kotlin 1.9.22
- **Giao diện**: Jetpack Compose (Material 3)
- **Cơ sở dữ liệu**: Room SQLite Database 2.6.1 (Lưu trữ offline 100%)
- **Báo thức**: Android AlarmManager (`setExactAndAllowWhileIdle`)
- **Khôi phục**: `BootAndConfigReceiver` (`BOOT_COMPLETED`, `TIME_SET`)

---

## 2. Cấu trúc thư mục chuẩn Android Studio
```text
SoTayMucTieu/
├── build.gradle.kts           (Tệp cấu hình build cấp project)
├── settings.gradle.kts        (Khai báo module :app và kho thư viện)
├── gradle.properties          (Cấu hình bộ nhớ JVM và AndroidX)
├── gradlew                    (Gradle wrapper script cho Linux/macOS)
├── gradlew.bat                (Gradle wrapper script cho Windows)
├── gradle/
│   ├── libs.versions.toml     (Version Catalog quản lý phiên bản)
│   └── wrapper/
│       ├── gradle-wrapper.jar (File Jar thực thi Gradle 8.5)
│       └── gradle-wrapper.properties
├── app/
│   ├── build.gradle.kts       (Cấu hình dependencies module app)
│   └── src/
│       └── main/
│           ├── AndroidManifest.xml
│           ├── java/com/sotay/muctieu/
│           │   ├── alarm/
│           │   ├── data/
│           │   └── ui/
│           └── res/
└── README.md
```

---

## 3. Hướng dẫn mở và chạy dự án trong Android Studio
1. Mở **Android Studio** (Hedgehog, Iguana, Jellyfish trở lên).
2. Chọn **File > Open**, chọn thư mục `SoTayMucTieu`.
3. Chờ Android Studio đồng bộ Gradle (**Sync Project with Gradle Files**).
4. Kết nối điện thoại **vivo T1x** qua cáp USB và bật **Gỡ lỗi USB (USB Debugging)**.
5. Bấm nút **Run 'app' (Shift + F10)**.

---

## 4. Tối ưu pin trên vivo T1x (Funtouch OS)
1. Vào **Cài đặt** > **Pin** > **Tiêu thụ pin ở chế độ nền** > Chọn **Sổ Tay Mục Tiêu** > Chọn **Cho phép hoạt động nền cao (High background power usage)**.
2. Mở màn hình Đa nhiệm (Recent apps) > Nhấn giữ icon Sổ Tay Mục Tiêu > Chọn **Khóa 🔒**.
3. Cấp quyền **Báo thức & lời nhắc (SCHEDULE_EXACT_ALARM)** nếu máy yêu cầu.
